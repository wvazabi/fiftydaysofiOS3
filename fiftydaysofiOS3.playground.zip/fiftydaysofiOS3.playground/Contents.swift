import UIKit

var dict : [String:String] = [:]


dict["Key"] = "Value"

print(dict["Key"]!)

dict["Key"] = "Valu2"


print(dict["Key"]!)

var str1 = "Kırmızı"
var str2 = "Beyaz"

var num1 = 7

var strSum = str1 + " " + "\(num1)" + str2

print(strSum)

var furuk: Any

furuk = 61

furuk = "Faruk"

var strSum2 = furuk as! String + str2




